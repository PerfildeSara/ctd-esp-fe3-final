import React from 'react'

const Footer = () => {
  return (
    <footer>
        <p>Powered by</p>
        <img src="./images/DH.png" alt='DH-logo' />
        <ul>
          <li type="none"><img src="./images/ico-facebook.png" alt='Facebook-logo' /></li>
          <li type="none"><img src="./images/ico-instagram.png" alt='Instagram-logo' /></li>
          <li type="none"><img src="./images/ico-tiktok.png" alt='Tiktok-logo' /></li>
          <li type="none"><img src="./images/ico-whatsapp.png" alt='Whatsapp-logo' /></li>

        </ul>
    </footer>
  )
}

export default Footer
