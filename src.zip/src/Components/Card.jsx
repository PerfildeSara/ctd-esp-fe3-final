import React from "react";

const Card = ({ dentista }) => {

  const addFav = ()=>{
    // Aqui iria la logica para agregar la Card en el localStorage
  }

  return (
    <div className="card-grid">
        {/* En cada card deberan mostrar en name - username y el id */}
        <div className="card">
            <div><img src="images/doctor.jpg" className="doctorImage" alt=""/></div>
            <h5>{dentista.name}</h5>
            <h6 >{dentista.userName}</h6>
            
        {/* No debes olvidar que la Card a su vez servira como Link hacia la pagina de detalle */}

        {/* Ademas deberan integrar la logica para guardar cada Card en el localStorage */}
        <button onClick={addFav} className="favButton">Add fav</button>
        </div>
    </div>
  );
};

export default Card;

