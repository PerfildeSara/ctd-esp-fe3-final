import React from 'react'
import { BrowserRouter, Routes, Route} from "react-router-dom";
import { Link, useNavigate } from 'react-router-dom';
import Home from "../Routes/Home.jsx"
import Contact from "../Routes/Contact.jsx"
import Favs from "../Routes/Favs.jsx"

//Este componente debera ser estilado como "dark" o "light" dependiendo del theme del Context


const Navbar = () => {

  const navigate = useNavigate()

  return (
    <div>
      <ul>
        <button onClick={() => navigate(-1)}>🔙</button>
          <Link to="/"><h2>Home</h2></Link>
          <Link to = "/Contact"><h2>Contact</h2></Link>
          <Link to="/Favs"><h2>Favs</h2></Link>
        </ul>
      <button>Change theme</button>
    </div>
  )
}
   

export default Navbar