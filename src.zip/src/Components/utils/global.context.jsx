import { createContext, useState, useEffect } from "react";
import axios from "axios";

//export const initialState = {theme: "", data: []}

export const ContextGlobal = createContext();

export const ContextProvider = ({ children }) => {
  //const ContextProvider = createContext();
  
  const[dentistas, setDentistas] = useState([]);
  
  useEffect(() => {
    axios
    .get("https://jsonplaceholder.typicode.com/users")
    .then((response) =>{
      setDentistas(response.data);      
    })
    .catch((error) => {
      console.log(error);
    });
  },[]);


  return (
    <ContextGlobal.Provider value={{dentistas}}>      
      {children}
    </ContextGlobal.Provider>
  );
};


/*
import { createContext } from "react";

export const initialState = {theme: "", data: []}

export const ContextGlobal = createContext(undefined);

export const ContextProvider = ({ children }) => {
  //Aqui deberan implementar la logica propia del Context, utilizando el hook useMemo

  return (
    <ContextGlobal.Provider value={{}}>
      {children}
    </ContextGlobal.Provider>
  );
};
*/