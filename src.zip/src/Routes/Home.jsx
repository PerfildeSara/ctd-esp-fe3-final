import React, { useContext } from 'react'
import Card from '../Components/Card'
import { ContextProvider } from '../Components/utils/global.context'


//Este componente debera ser estilado como "dark" o "light" dependiendo del theme del Context

const Home = () => {
  const context = useContext(ContextProvider)  
  const dentistas = context


  
  return (
    <main className="" >
      <h1>Home</h1>
      <div className='card-grid'>
        {dentistas.map((dentista) => (
          <Card key={dentista.id} dentista ={dentista} />
        ))}
        
      </div>
    </main>
  )
}

export default Home


/*import React from 'react'
import Card from '../Components/Card'
import { useEffect, useState } from 'react'
import axios from 'axios'


//Este componente debera ser estilado como "dark" o "light" dependiendo del theme del Context

const Home = () => {
  const [dentista, setDentista] = useState([]);

  useEffect(() => {
    axios
    .get("https://jsonplaceholder.typicode.com/users")
    .then((response) =>{
      setDentista(response.data);
    })
    .catch((error) => {
      console.log(error);
    });
  },[]);
  
  return (
    <main className="" >
      <h1>Home</h1>
      <div className='card-grid'>
        {dentista.map((dentista) => (
          <Card key={dentista.id} dentista ={dentista} />
        ))}
        
      </div>
    </main>
  )
}

export default Home*/